exports.getActions = (instance) => {
    return {
        // Preset loading
        load_preset_ss0: {
            name: 'Load Preset on SS0',
            options: [
                {
                    type: 'dropdown',
                    id: 'preset',
                    label: 'Preset',
                    choices: Object.keys(instance.presets).map(name => ({
                        id: name,
                        label: name,
                    })),
                    default: 'PPT RIGHT',
                },
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: '/api/presets/load',
                    body: {
                        name: action.options.preset,
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },

        load_preset_ss1: {
            name: 'Load Preset on SS1',
            options: [
                {
                    type: 'dropdown',
                    id: 'preset',
                    label: 'Preset',
                    choices: Object.keys(instance.presets).map(name => ({
                        id: name,
                        label: name,
                    })),
                    default: 'PPT RIGHT',
                },
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: '/api/presets/load',
                    body: {
                        name: action.options.preset,
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },

        // Box large
        box_large_ss0: {
            name: 'Make Box Large on SS0',
            options: [
                {
                    type: 'dropdown',
                    id: 'box',
                    label: 'Box',
                    choices: [
                        { id: '0', label: 'Box 1' },
                        { id: '1', label: 'Box 2' },
                        { id: '2', label: 'Box 3' },
                        { id: '3', label: 'Box 4' },
                    ],
                    default: '0',
                },
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: `/api/ss/0/box/${action.options.box}/large`,
                    body: {
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },

        box_large_ss1: {
            name: 'Make Box Large on SS1',
            options: [
                {
                    type: 'dropdown',
                    id: 'box',
                    label: 'Box',
                    choices: [
                        { id: '0', label: 'Box 1' },
                        { id: '1', label: 'Box 2' },
                        { id: '2', label: 'Box 3' },
                        { id: '3', label: 'Box 4' },
                    ],
                    default: '0',
                },
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: `/api/ss/1/box/${action.options.box}/large`,
                    body: {
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },

        // Return to preset
        return_ss0: {
            name: 'Return to Preset on SS0',
            options: [
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: '/api/ss/0/return',
                    body: {
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },

        return_ss1: {
            name: 'Return to Preset on SS1',
            options: [
                {
                    type: 'textinput',
                    id: 'duration',
                    label: 'Duration (ms)',
                    default: '500',
                    regex: '/^\\d+$/',
                },
            ],
            callback: async (action) => {
                await instance.handleAction({
                    endpoint: '/api/ss/1/return',
                    body: {
                        durationMs: parseInt(action.options.duration),
                    },
                })
            },
        },
    }
}
