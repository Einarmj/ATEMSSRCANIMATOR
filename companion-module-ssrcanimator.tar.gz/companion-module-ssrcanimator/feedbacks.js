exports.getFeedbacks = (instance) => {
    return {
        active_preset_ss0: {
            type: 'boolean',
            name: 'SS0: Highlight if Preset Active',
            description: 'Highlight button when this preset is active on SS0',
            options: [
                {
                    type: 'dropdown',
                    id: 'preset',
                    label: 'Preset',
                    choices: Object.keys(instance.presets).map(name => ({
                        id: name,
                        label: name,
                    })),
                    default: 'PPT RIGHT',
                },
            ],
            callback: (feedback) => {
                return instance.state[0].preset === feedback.options.preset
            },
            defaultStyle: {
                bgcolor: 0x00cc00,
                color: 0x000000,
            },
        },

        active_preset_ss1: {
            type: 'boolean',
            name: 'SS1: Highlight if Preset Active',
            description: 'Highlight button when this preset is active on SS1',
            options: [
                {
                    type: 'dropdown',
                    id: 'preset',
                    label: 'Preset',
                    choices: Object.keys(instance.presets).map(name => ({
                        id: name,
                        label: name,
                    })),
                    default: 'PPT RIGHT',
                },
            ],
            callback: (feedback) => {
                return instance.state[1].preset === feedback.options.preset
            },
            defaultStyle: {
                bgcolor: 0x00cc00,
                color: 0x000000,
            },
        },
    }
}
